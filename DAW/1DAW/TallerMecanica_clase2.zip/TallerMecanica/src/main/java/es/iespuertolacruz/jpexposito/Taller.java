
package es.iespuertolacruz.jpexposito;

/**
 * Clase encargada de lanzar la aplicacion a traves del menu
 * @author jpexposito
 */
public class Taller {
    
}


package es.iespuertolacruz.jpexposito.elementos;

/**
 *
 * @author jpexposito
 */
public class Coche extends Vehiculo{

    public Coche(String marca, String modelo, String matricula) throws Exception {
        super(marca, modelo, matricula);
    }
    
    
    
}

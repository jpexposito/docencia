
package es.iespuertolacruz.utils;

public class SocketUtils {
    
    public static Integer PORT = 10578;
    public static String IP_SERVER = "127.0.0.1";
}
